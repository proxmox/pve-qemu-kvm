#ifndef TRACE_H
#define TRACE_H

#include "trace/generated-tracers.h"
#include "trace/generated-events.h"

#endif  /* TRACE_H */
