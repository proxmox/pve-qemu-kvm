#ifndef TRACE_TCG_H
#define TRACE_TCG_H

#include "trace/generated-tcg-tracers.h"
#include "trace/generated-events.h"

#endif  /* TRACE_TCG_H */
