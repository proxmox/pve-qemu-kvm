#ifndef HW_PPC_E500_H
#define HW_PPC_E500_H

void ppce500_set_mpic_proxy(bool enabled);

#endif
